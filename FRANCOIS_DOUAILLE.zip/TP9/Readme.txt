Douaille Erwan
Francois Remy

Nous avons bloqué sur l'avant dernière question. Nous avons bien complété comme indiqué dans l'énoncé mais le résultat n'est pas la. La détection de collision fonctionne mais n'est pas opérationelle

Autrement l'ensemble du sujet a été clairement compris :)
